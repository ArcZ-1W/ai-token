var settings = { enableFileDownload: true };

function escapeRegExp(str) {
  return String(str).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function parseFileDownloadPayload(raw) {
  if (!raw || typeof raw !== 'string' || !settings.enableFileDownload) return { content: raw, files: [] };
  var matches = raw.matchAll(/<FILE_DOWNLOAD>\s*(\{[\s\S]*?\}|\[[\s\S]*?\])\s*<\/FILE_DOWNLOAD>/gi);
  var blocks = [];
  for (var m of matches) blocks.push(m[1]);
  if (!blocks.length) return { content: raw, files: [] };
  var files = [];
  for (var i = 0; i < blocks.length; i++) {
    try {
      var parsed = JSON.parse(blocks[i]);
      var items = Array.isArray(parsed) ? parsed : [parsed];
      for (var j = 0; j < items.length; j++) {
        var item = items[j];
        if (!item || typeof item !== 'object') continue;
        var filename = (item.filename && String(item.filename).trim()) || ('download_' + Date.now() + '_' + j + '.txt');
        var mime = (item.mime && String(item.mime).trim()) || 'text/plain';
        var content = (typeof item.content === 'string') ? item.content : '';
        if (!content) continue;
        files.push({ filename: filename, mime: mime, blobUrl: 'blob:' + filename });
      }
    } catch (err) {
      console.warn('File download block invalid:', err);
    }
  }
  if (!files.length) return { content: raw, files: [] };
  var text = raw;
  for (var k = 0; k < blocks.length; k++) {
    text = text.replace(new RegExp('<FILE_DOWNLOAD>\\s*' + escapeRegExp(blocks[k]) + '\\s*<\\/FILE_DOWNLOAD>', 'i'), '');
  }
  return { content: text.replace(/\n{3,}/g, '\n\n').trim(), files: files };
}

var raw = 'Halo\n<FILE_DOWNLOAD>{"filename":"a.txt","mime":"text/plain","content":"abc"}</FILE_DOWNLOAD>\n<FILE_DOWNLOAD>{"filename":"b.md","mime":"text/markdown","content":"# hi"}</FILE_DOWNLOAD>';
var out = parseFileDownloadPayload(raw);
console.log(JSON.stringify(out, null, 2));
